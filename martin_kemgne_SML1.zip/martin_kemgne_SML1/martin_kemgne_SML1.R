

#Name:    Martin WAFFO KEMGNE
#Course:  R code path of Statistical Machine Learning for Data Science
# Assignment 1
#
#



#Exercise 2: Investigating the Bayes risk R⋆is Regression
#Package to use
library(MASS)
library(rpart)
library(class)
library(caret)
library(dplyr)
library(PreProcessing)
library(dslabs) 
library(ROCR)



#2) Let n = 99. Generate {(Xi, Yi), i = 1, · · · , n}, an iid sample of size n where each (Xi
#  , Yi) as density p(x, y). [Hint: Draw each Xi from the marginal of X, and then draw the
# corresponding Yi from the conditional distribution of Y given X.] . 
# 


creation_of_data = function(n)
{
  var_Xi <- runif (n, min=0, max=2*pi)
  
  var_Yi <- rnorm(n, mean=pi/2*var_Xi+3*pi/4*cos(pi/2*(1+var_Xi)), sd = 3/pi)
  
  return(cbind(var_Xi, var_Yi))
}
n = 99

abs_ord <- creation_of_data(n)
Firstx_to_x <- abs_ord[,1]
Firstx_to_y <- abs_ord[,2]

# 3)  Draw the scatterplot from {(Xi, Yi), i = 1, · · · , n}.

plot(Firstx_to_x, Firstx_to_y, col = "red", main = "Graphe of scatterplot of (Xi,Yi)")


# 4.Consider now using regression analysis learning machines to learn the true function under-
#lying your created dataset. We are herein learning under the squared error loss, namely
#l(Y, f(X)) = (Y − f(X))2, with corresponding risk functional



n = 99
Observation_proportion <- 0.6 #Proportion of observations
nObservatr <- round(n*Observation_proportion) # This give the observations for training set set
nte <- n - nObservatr # This give the observations for training set set
ind<- sample(sample(c(rep(TRUE,nObservatr), rep(FALSE, nte))))
R <- 100 # This is the variable for replication


test_err <- matrix(0, nrow = R, ncol = 4)#Variable for test error


for(r in 1:R)
{
  abs_ord <- creation_of_data(n)
  Firstx_to_x <- abs_ord[,1]
  Firstx_to_y <- abs_ord[,2]
  
  train_of_x <- Firstx_to_x[ind]
 train_of_y <- Firstx_to_y[ind]
  
  training <- data.frame(cbind(train_of_x,train_of_y))
  colnames(training) <- c("x", "y")
  
 test_for_x <- Firstx_to_x[!ind]
 test_for_y <- Firstx_to_y[!ind]
  
  
  x <-test_for_x
  
  # For (a) kNN regression
 kNN_regression <- knnreg(y ~ x, data = training)
  y_pred <- predict(knn_reg, data.frame(x))
  test_err[r,1] <- mean((y_test - y_pred)^2)
  # For (b) Linear regression 
 Simple_reg <- lm(y ~ x, data = training)
  y_pred <- predict(simpl_reg, data.frame(x))
  test_err[r,2] <- mean((y_test - y_pred)^2)
  # For (c) Polynomial Regression
  poly_reg <- lm(y ~ poly(x, 5), data = training)
  y_pred <- predict(poly_reg, data.frame(x))
  test_err[r,3] <- mean((y_test - y_pred)^2)
  #For (d) Regression tree learner
  tree_reg <- rpart(y ~ x, data = training)
  y_pred <- predict(tree_reg, data.frame(x))
  test_err[r,4] <- mean((y_test - y_pred)^2)
}
# plot the comparative boxplots of the test errors based on 100 replications,
#for a,b,d
Observation_proportion_test <- data.frame(test_err)
colnames(Observation_proportion_test) <- c("kNNregr", "Linression ", "PoRegr","Regrtlea")
boxplot(Observation_proportion_test)

# Exercise 3: Practical Machine Learning - Digit Recognition


#1. Choose n a training set size and m a test set size, and write a piece of code for sampling
#a fragment from the large dataset. Explain why you choose the numbers you chose.



set.seed(19671210)
mnist <- read_mnist() # Read in themnist_data data
str(mnist)
# Combine the data training
Training <- data.frame(cbind(mnist$train$images,mnist$train$labels))
pos <- ncol(Training)
# Extract from the data training all the observations with the labels "1" and "7"
Training <- Training[Training$X785 %in% c(1,7),]
# Training dataset
dim(Training)
xtrain <- Training[,-pos]
ytrain <- Training[,pos]
ytrain <- as.factor(ytrain)
ytrain <- factor(ytrain, levels = c("1","7"), labels = c("1","0"))

# Same process for Test

Test <- data.frame(cbind(mnist$test$images,mnist$test$labels))
pos_te <- ncol(Training)
Test <- Test[Test$X785 %in% c(1,7),]
xtest <- Test[,-pos]
ytest <- Test[,pos]
ytest <- as.factor(ytest)
ytest <- factor(ytest, levels = c("1","7"), labels = c("1","0"))



# 1. WE WILL START BY OBTAIN THE CLASSIFIERS
stratified.holdout <- function(y, ptr)
{
  n              <- length(y)
  labels         <- unique(y)      
  id.tr          <- id.te <- NULL
  y <- sample(sample(sample(y))) 
  
  for(j in 1:length(labels)) # Loop once for each unique label value
  {
    sj    <- which(y==labels[j])  # Grab all rows of label type j  
    nj    <- length(sj)           # Count of label j rows to calc proportion below
    id.tr <- c(id.tr, (sample(sample(sample(sj))))[1:round(nj*ptr)])
  }                               # Concatenates each label type together 1 by 1
  id.te  <- (1:n) [-id.tr]          # Obtain and Shuffle test indices to randomize                                
  return(list(idx1=id.tr,idx2=id.te)) 
} 

hold  <- stratified.holdout(ytrain, 0.5) 
id_tr <- hold$idx1
nObservatr   <- length(id_tr)
n = nObservatr
m <- length(ytrain)-n
hold  <- stratified.holdout(ytest, 0.5)
id_te <- hold$idx1
nte   <- length(id_te)
xtr <- xtrain[id_tr,]
ytr <- ytrain[id_tr]
xte <- xtest[id_te,]
yte <- ytest[id_te]

# 2 Display both the training confusion matrix and the test confusion matrix for each of the 
#  four learning machines under consideration.

ytr_kNN1 <- knn(xtr, xtr, ytr, k=1, prob=TRUE)
yte_kNN1 <- knn(xtr, xte, ytr, k=1, prob=TRUE)
confM_tr_kNN1 <- table(ytr,Training_for_firstKNN)
confM_tr_kNN1
confM_te_kNN1 <- table(yte, yte_kNN1)
confM_te_kNN1
ytr_kNN9 <- knn(xtr, xtr, ytr, k=9, prob=TRUE)
yte_kNN9 <- knn(xtr, xte, ytr, k=9, prob=TRUE)
confM_tr_kNN9 <- table(ytr, ytr_kNN9)
confM_tr_kNN9
confM_te_kNN9 <- table(yte, yte_kNN9)
confM_te_kNN9

ytr_kNN18 <- knn(xtr, xtr, ytr, k=18, prob=TRUE)
yte_kNN18 <- knn(xtr, xte, ytr, k=18, prob=TRUE)

confM_tr_kNN18 <- table(ytr,Training_for_firstKNN8)
confM_tr_kNN18
confM_te_kNN18 <- table(yte, yte_kNN18)
confM_te_kNN18


# 27NN
ytr_kNN27 <- knn(xtr, xtr, ytr, k=27, prob=TRUE)
yte_kNN27 <- knn(xtr, xte, ytr, k=27, prob=TRUE)

confM_tr_kNN27 <- table(ytr, ytr_kNN27)
confM_tr_kNN27
confM_te_kNN27 <- table(yte, yte_kNN27)
confM_te_kNN27


# 3. Display the comparative ROC curves of the four learning machines, and do so for both
#    the training set and the test set.

# Training

# 1NN
prob <- attr(ytr_kNN1, 'prob')
prob <- 2*ifelse(ytr_kNN1 == "0", 1-prob, prob) - 1

pred_1NN <- prediction(prob, ytr)
perf_1NN <- performance(pred_1NN, measure='tpr', x.measure='fpr')
prob <- attr(ytr_kNN9, 'prob')
prob <- 2*ifelse(ytr_kNN9 == "0", 1-prob, prob) - 1
pred_9NN <- prediction(prob, ytr)
perf_9NN <- performance(pred_9NN, measure='tpr', x.measure='fpr')
prob <- attr(ytr_kNN18, 'prob')
prob <- 2*ifelse(ytr_kNN18 == "0", 1-prob, prob) - 1
pred_18NN <- prediction(prob, ytr)
perf_18NN <- performance(pred_18NN, measure='tpr', x.measure='fpr')
prob <- attr(ytr_kNN27, 'prob')
prob <- 2*ifelse(ytr_kNN27 == "0", 1-prob, prob) - 1
pred_27NN <- prediction(prob, ytr)
perf_27NN <- performance(pred_27NN, measure='tpr', x.measure='fpr')
plot(perf_1NN, col=2, lwd= 2, lty=2, main=paste('Comparison of Predictive ROC curves for test'))
plot(perf_9NN, col=3, lwd= 2, lty=3, add=TRUE)
plot(perf_18NN, col=4, lwd= 2, lty=4, add=TRUE)
plot(perf_27NN, col=4, lwd= 2, lty=4, add=TRUE)
abline(a=0,b=1)
legend('bottomright', inset=0.05, c('1NN','9NN', '18NN', '27NN'),  col=2:4, lty=2:4)
prob <- attr(yte_kNN1, 'prob')
prob <- 2*ifelse(yte_kNN1 == "0", 1-prob, prob) - 1
pred_1NN <- prediction(prob, yte)
perf_1NN <- performance(pred_1NN, measure='tpr', x.measure='fpr')
prob <- attr(yte_kNN9, 'prob')
prob <- 2*ifelse(yte_kNN9 == "0", 1-prob, prob) - 1
pred_9NN <- prediction(prob, yte)
perf_9NN <- performance(pred_9NN, measure='tpr', x.measure='fpr')
prob <- attr(yte_kNN18, 'prob')
prob <- 2*ifelse(yte_kNN18 == "0", 1-prob, prob) - 1
pred_18NN <- prediction(prob, yte)
perf_18NN <- performance(pred_18NN, measure='tpr', x.measure='fpr')
prob <- attr(yte_kNN27, 'prob')
prob <- 2*ifelse(yte_kNN27 == "0", 1-prob, prob) - 1

pred_27NN <- prediction(prob, yte)
perf_27NN <- performance(pred_27NN, measure='tpr', x.measure='fpr')

# Comparison graphics

plot(perf_1NN, col=2, lwd= 2, lty=2, main=paste('Comparison of Predictive ROC curves for test'))
plot(perf_9NN, col=3, lwd= 2, lty=3, add=TRUE)
plot(perf_18NN, col=4, lwd= 2, lty=4, add=TRUE)
plot(perf_27NN, col=4, lwd= 2, lty=4, add=TRUE)
abline(a=0,b=1)
legend('bottomright', inset=0.05, c('1NN','9NN', '18NN', '27NN'),  col=2:4, lty=2:4)


# 4. Identify two false positives and two false negatives at the test phase, and in each case,
#    plot the true image against its falsely predicted counterpart.


# Plots of true image against falsely pxtr.pca redicted counterpart.

# 1NN

# 5


# 6 Perform principal component analysis on the data matrix and extract the first two components
# and plot them using the R Code provided
pca.tr <- prcomp(xtr)

pc <- pca.tr$x[,1:2]

plot(pc, col=1+as.numeric(ytr)) 

# 7 Compare the predictive performance of 9NN on two PC scores to the one var_Yielded by all
#   the original variables. Provide a comprehensive comment.

xtr.pca <- as.matrix(xtr)%*%pca_tr$rotation[,1:2]
xte.pca <- as.matrix(xte)%*%pca.tr$rotation[,1:2]

xtr.pca <- predict(pca.tr,xtr)[,1:2]
xte.pca <- predict(pca.tr,xte)[,1:2]

yte.knn.pca <- knn(xtr.pca, xte.pca, ytr, k=9, prob = TRUE)

prob <- attr(yte.knn.pca, 'prob')
prob <- 2*ifelse(yte.knn.pca == "0", 1-prob, prob) - 1

pred9NN.pca <- prediction(prob, yte)
perf_9NN_pca <- performance(pred9NN.pca, measure='tpr', x.measure='fpr')

plot(perf_9NN, col=2, lwd= 2, lty=2, main=paste('Comparison of Performance'))
plot(perf_9NN_pca, col=3, lwd= 2, lty=4, add=TRUE)
abline(a=0,b=1)
legend('bottomright', inset=0.05, c('9NN','9NN_PCA'),  col=2:4, lty=2:4)



